package com.acadgild.myfirstapp.intent_ass3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by E9900317 on 5/17/2016.
 */
public class SecondActivity extends Activity {

    String[] inst = {"Sonali","Shreya","Priya","Ankit","Khush","Prajakta","Palak","Rekha"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        TextView textView = (TextView)findViewById(R.id.textt);
        Intent intent = getIntent();
        int pos = intent.getExtras().getInt("position");
        textView.setText(inst[pos]);


    }
}

